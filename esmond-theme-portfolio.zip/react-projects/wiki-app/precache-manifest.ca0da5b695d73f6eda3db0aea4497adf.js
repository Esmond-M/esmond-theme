self.__precacheManifest = [
  {
    "revision": "b38190a1ec6d628bbeba",
    "url": "/react-projects/wiki-app/static/css/main.1638eb2d.chunk.css"
  },
  {
    "revision": "b38190a1ec6d628bbeba",
    "url": "/react-projects/wiki-app/static/js/main.b38190a1.chunk.js"
  },
  {
    "revision": "338433097ca804b12078",
    "url": "/react-projects/wiki-app/static/css/1.1ab24b81.chunk.css"
  },
  {
    "revision": "338433097ca804b12078",
    "url": "/react-projects/wiki-app/static/js/1.33843309.chunk.js"
  },
  {
    "revision": "172cbf253533b04e7c26",
    "url": "/react-projects/wiki-app/static/js/runtime~main.172cbf25.js"
  },
  {
    "revision": "45efda9cf4c7f2410cc33e223a96f028",
    "url": "/react-projects/wiki-app/static/media/wiki.45efda9c.svg"
  },
  {
    "revision": "ff25ff9ff22f07b60eecdb5bec3053b3",
    "url": "/react-projects/wiki-app/static/media/wikipedia-icon.ff25ff9f.png"
  },
  {
    "revision": "954860e4f483d6dd973301dfce747138",
    "url": "/react-projects/wiki-app/index.html"
  }
];